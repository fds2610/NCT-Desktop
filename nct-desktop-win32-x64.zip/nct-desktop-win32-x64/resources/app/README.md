# NCT-Desktop
Desktop-App for notifying Nextcloud-Talk Events

This is my very first GIT repository and my very first Desktop App.
please comment to me whatever your might want to express, but be polite.

I create this app for my personal use and i want to let the community 
participate on my outcome and experiences. In the first step i start
using GITHUB as a source backup, so i will not create too many branches
and commit regularly direct to master branch. As soon as others want to
participate, i might rethink this approach.

regards, FDS

btw: this is an ELECTRON-project. See https://www.electronjs.org/ for details.
